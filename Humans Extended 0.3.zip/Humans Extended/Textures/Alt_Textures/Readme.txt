Basically This Folder Simply has replacement textures, Just Copy Paste it over to the Texture folder with the one you like, and delete the number at the end in the file name. 

Don't worry about the orginal texture, it should be here unless you delete it. 

I've also included 2 .xcf files so you can modifiy the head placement itself, or add more to it if you'd like. (They're basically Photoshop files, but for GIMP. It should work with photoshop but Im not spending $300 on it to see if it works.)